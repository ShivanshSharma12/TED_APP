import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    home: Scaffold(
      appBar: AppBar(
        leading: Image.asset("assets/logo.png"),
        backgroundColor: Colors.black,
        centerTitle: true,
        title: const Text("Ted Talk"),
        actions: const [Icon(Icons.search),
        SizedBox(width: 20,),
        Icon(Icons.more_vert)],
      ),
      body: SingleChildScrollView(scrollDirection: Axis.vertical,
        child: Column(
        
          children: [
            
            Stack(
              alignment: Alignment.center, 
              children: [
                Padding(
                  padding: const EdgeInsets.only(left: 50),
                  child: Column(
                    children: [
                      Container(
                        height: 200,
                        width: 300,
                        child: Image.asset("assets/ted1.jpg"),
                      ),
                    ],
                  ),
                  
                ),
                Positioned(
                  left: 50,
                  bottom: 8,
                  child: Container(
                    padding: const EdgeInsets.all(2),
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.6),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Text(
                      "Ted Talk Speaker 1",
                      style: TextStyle(fontSize: 18, color: Colors.white),
                    ),
                  ),
                
                ),
                
              ],
            ),
            Stack(
              alignment: Alignment.center, 
              children: [
                Padding(
                  padding: const EdgeInsets.only(left: 50),
                  child: Container(
                    height: 200,
                    width: 300,
                    child: Image.asset("assets/ted2.jpeg"),
                  ),
                ),
                Positioned(
                  left: 50,
                  bottom: 8,
                  child: Container(
                    padding: const EdgeInsets.all(2),
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.6),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Text(
                      "Ted Talk Speaker 2",
                      style: TextStyle(fontSize: 18, color: Colors.white),
                    ),
                  ),
                ),
              ],
            ),
            Stack(
              alignment: Alignment.center, 
              children: [
                Padding(
                  padding: const EdgeInsets.only(left: 50),
                  child: Container(
                    height: 200,
                    width: 300,
                    child: Image.asset("assets/ted3.jpeg"),
                  ),
                ),
                Positioned(
                  left: 50,
                  bottom: 8,
                  child: Container(
                    padding: const EdgeInsets.all(2),
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.6),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Text(
                      "Ted Talk Speaker 3",
                      style: TextStyle(fontSize: 18, color: Colors.white),
                    ),
                  ),
                ),
              ],
            ),
            Stack(
              alignment: Alignment.center, 
              children: [
                Padding(
                  padding: const EdgeInsets.only(left: 50),
                  child: Container(
                    height: 200,
                    width: 300,
                    child: Image.asset("assets/ted3.jpeg"),
                  ),
                ),
                Positioned(
                  left: 50,
                  bottom: 8,
                  child: Container(
                    padding: const EdgeInsets.all(2),
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.6),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Text(
                      "Ted Talk Speaker 3",
                      style: TextStyle(fontSize: 18, color: Colors.white),
                    ),
                  ),
                ),
              ],
            ),
            Stack(
              alignment: Alignment.center, 
              children: [
                Padding(
                  padding: const EdgeInsets.only(left: 50),
                  child: Container(
                    height: 200,
                    width: 300,
                    child: Image.asset("assets/ted3.jpeg"),
                  ),
                ),
                Positioned(
                  left: 50,
                  bottom: 8,
                  child: Container(
                    padding: const EdgeInsets.all(2),
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.6),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Text(
                      "Ted Talk Speaker 3",
                      style: TextStyle(fontSize: 18, color: Colors.white),
                    ),
                  ),
                ),
              ],
            ),
            Stack(
              alignment: Alignment.center,
              children: [
                Padding(
                  padding: const EdgeInsets.only(left: 50),
                  child: Container(
                    height: 200,
                    width: 300,
                    child: Image.asset("assets/ted3.jpeg"),
                  ),
                ),
                Positioned(
                  left: 50,
                  bottom: 8,
                  child: Container(
                    padding: const EdgeInsets.all(2),
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.6),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Text(
                      "Ted Talk Speaker 3",
                      style: TextStyle(fontSize: 18, color: Colors.white),
                    ),
                  ),
                ),
              ],
            ),
           
          ],
        ),
      ),
    ),
  ));
}
